var xbuy = sessionStorage.getItem("buy");
var xsell = sessionStorage.getItem("sell");
// the pyment data load 
document.getElementById("asell").innerText = xsell;
document.getElementById("abuy").innerText = xbuy;  

